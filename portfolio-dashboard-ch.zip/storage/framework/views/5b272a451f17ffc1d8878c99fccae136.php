<!-- resources/views/news/show.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <h1><?php echo e($news->title); ?></h1>
    <p><?php echo e($news->description); ?></p>
    <p><strong>Date:</strong> <?php echo e($news->date); ?></p>
    <img src="<?php echo e(asset('storage/' . $news->image)); ?>" alt="Image" width="300">
    <br><br>
    <a href="<?php echo e(route('news.index')); ?>" class="btn btn-secondary">Back to news</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\portfolio-dashboard-ch\resources\views/home/news/show.blade.php ENDPATH**/ ?>