<!-- resources/views/blogs/show.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <h1><?php echo e($blog->title); ?></h1>
    <p><?php echo e($blog->description); ?></p>
    <p><strong>Date:</strong> <?php echo e($blog->date); ?></p>
    <img src="<?php echo e(asset('storage/' . $blog->image)); ?>" alt="Image" width="300">
    <br><br>
    <a href="<?php echo e(route('blog.index')); ?>" class="btn btn-secondary">Back to Blogs</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\portfolio-dashboard-ch\resources\views/blogs/show.blade.php ENDPATH**/ ?>