


<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Business Details</h1>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Id: <?php echo e($business_category->id); ?></h5>
            <p class="card-text">Category Name: <?php echo e($business_category->category_name); ?></p>
        </div>
    </div>

    <a href="<?php echo e(route('business_category.index')); ?>" class="btn btn-secondary mt-3">Back to List</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\portfolio-dashboard-ch\resources\views/business_categories/show.blade.php ENDPATH**/ ?>