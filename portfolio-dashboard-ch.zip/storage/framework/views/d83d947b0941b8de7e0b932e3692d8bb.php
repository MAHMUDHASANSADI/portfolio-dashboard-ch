


<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Business Details</h1>

    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Name: <?php echo e($business->businessCategory->category_name); ?></h4>
            <h5 class="card-title">Name: <?php echo e($business->name); ?></h5>
            <p class="card-text">Description: <?php echo e($business->description); ?></p>
        </div>
    </div>

    <a href="<?php echo e(route('business.index')); ?>" class="btn btn-secondary mt-3">Back to List</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\portfolio-dashboard-ch\resources\views/businesses/show.blade.php ENDPATH**/ ?>