<!-- resources/views/sliders/show.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
   
    <img src="<?php echo e(asset('storage/'.$slider->image)); ?>" alt="Image" width="300">
    <br><br>
    <a href="<?php echo e(route('slider.index')); ?>" class="btn btn-secondary">Back to Blogs</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\portfolio-dashboard-ch\resources\views/home/slider/show.blade.php ENDPATH**/ ?>