<!-- resources/views/blogs/index.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>All Blogs</h1>
    <a href="<?php echo e(route('blog.create')); ?>" class="btn btn-primary mb-3">Add New Blog</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Image</th>
                <th>Title</th>
                <th>Description</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><img src="<?php echo e(asset('storage/' . $blog->image)); ?>" alt="Image" width="50"></td>
                <td><?php echo e($blog->title); ?></td>
                <td><?php echo e(Str::limit($blog->description, 50)); ?></td>
                <td><?php echo e($blog->date); ?></td>
                <td>
                    <a href="<?php echo e(route('blog.show', $blog->id)); ?>" class="btn btn-info btn-sm">View</a>
                    <a href="<?php echo e(route('blog.edit', $blog->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('blog.destroy', $blog->id)); ?>" method="POST" style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\portfolio-dashboard-ch\resources\views/blogs/index.blade.php ENDPATH**/ ?>