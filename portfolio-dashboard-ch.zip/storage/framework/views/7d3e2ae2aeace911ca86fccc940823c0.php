<!-- resources/views/heros/show.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <h1><?php echo e($hero->title); ?></h1>
    <p><?php echo e($hero->description); ?></p>
    <img src="<?php echo e(asset('storage/' . $hero->image)); ?>" alt="Image" width="300">
    <br><br>
    <a href="<?php echo e(route('hero.index')); ?>" class="btn btn-secondary">Back to Blogs</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\portfolio-dashboard-ch\resources\views/home/hero/show.blade.php ENDPATH**/ ?>