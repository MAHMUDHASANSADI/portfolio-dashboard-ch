


<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Video Details</h1>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Name: <?php echo e($video->title); ?></h5>
            <p class="card-text">Description: <?php echo e($video->description); ?></p>
            <p class="card-text">URL: <?php echo e($video->url); ?></p>
        </div>
    </div>

    <a href="<?php echo e(route('video.index')); ?>" class="btn btn-secondary mt-3">Back to List</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\portfolio-dashboard-ch\resources\views/videos/show.blade.php ENDPATH**/ ?>